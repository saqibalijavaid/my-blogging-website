class Config:
    DB_HOST = 'localhost'
    DB_USER = 'root'
    DB_PASSWORD = '02032004'
    DB_NAME = 'flaskweb'
    DB_PORT = 3306
